# DjangoAzure [![Deploy to Azure](http://azuredeploy.net/deploybutton.png)](https://azuredeploy.net/)

Django makes it easier to build better Web apps more quickly and with less code.[Get started with Django](https://www.djangoproject.com/start/)

## Local development 
You can use [Python Tools for Visual Studio](https://www.visualstudio.com/vs/python) to create django apps from scratch or use any one of the Django sample templates. Check out [this article](https://docs.microsoft.com/en-us/azure/app-service-web/web-sites-python-ptvs-django-mysql) on how to use a use Visual studio to locally develop your app for Azure. 
