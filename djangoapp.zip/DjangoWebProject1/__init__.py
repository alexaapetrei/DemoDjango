"""
Package for DjangoWebProject1.
"""
